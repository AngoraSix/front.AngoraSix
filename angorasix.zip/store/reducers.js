import { combineReducers } from 'redux';
import app from './app';

const reducers = combineReducers({
  app,
});

export default reducers;
