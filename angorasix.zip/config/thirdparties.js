class ThirdParties {
  constructor(env) {
    
  }
}

export default ThirdParties;
