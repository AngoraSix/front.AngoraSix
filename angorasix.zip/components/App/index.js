import App from './App.container';

export default App;
