import AcceptedInvitation from './AcceptedInvitation.component';

export default AcceptedInvitation;
