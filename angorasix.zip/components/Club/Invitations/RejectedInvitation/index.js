import RejectedInvitation from './RejectedInvitation.component';

export default RejectedInvitation;
