import ProjectManagementViewContainer from './ProjectManagementView.container';

export default ProjectManagementViewContainer;
