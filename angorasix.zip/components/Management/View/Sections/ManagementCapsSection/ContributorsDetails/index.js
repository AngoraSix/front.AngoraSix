import ContributorsDetails from './ContributorsDetails.component';

export default ContributorsDetails;
