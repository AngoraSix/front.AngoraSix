import ManagementCapsSection from './ManagementCapsSection.container';

export default ManagementCapsSection;
