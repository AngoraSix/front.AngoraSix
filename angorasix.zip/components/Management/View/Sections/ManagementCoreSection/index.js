import ManagementCoreSection from './ManagementCoreSection.component';

export default ManagementCoreSection;
