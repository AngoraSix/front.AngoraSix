import ManagementContributorsList from './ManagementContributorsList.component';

export default ManagementContributorsList;
