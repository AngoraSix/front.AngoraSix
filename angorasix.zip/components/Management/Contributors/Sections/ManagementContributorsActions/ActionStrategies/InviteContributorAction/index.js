import InviteContributorAction from './InviteContributorAction.container';

export default InviteContributorAction;
