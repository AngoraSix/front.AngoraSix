import ManagementContributorsActions from './ManagementContributorsActions.container';

export default ManagementContributorsActions;
