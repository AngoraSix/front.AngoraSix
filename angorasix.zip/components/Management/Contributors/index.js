import ManagementContributorsContainer from './ManagementContributors.container';

export default ManagementContributorsContainer;
