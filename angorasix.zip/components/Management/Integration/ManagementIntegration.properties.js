export const INTERACTION_PHASE = {
  register: 'PHASE_REGISTER',
}

export const INTERCOMMUNICATION_KEYS = {
  sourceSyncConfigCompleted: 'sourceSyncConfigCompleted',
}

export const INTEGRATION_QUERY_PARAMS = {
  multipleStepProcess: 'multiplestep',
}