import ManagementIntegrationList from './ManagementIntegrationList.container';

export default ManagementIntegrationList;
