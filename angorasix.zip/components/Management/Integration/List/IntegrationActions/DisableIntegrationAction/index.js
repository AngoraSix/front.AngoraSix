import DisableIntegrationAction from './DisableIntegrationAction.component';

export default DisableIntegrationAction;
