import IntegrationActions from './IntegrationActions.container';

export default IntegrationActions;
