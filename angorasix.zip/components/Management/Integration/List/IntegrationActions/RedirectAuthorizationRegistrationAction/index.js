import RedirectAuthorizationRegistrationAction from './RedirectAuthorizationRegistrationAction.component';

export default RedirectAuthorizationRegistrationAction;
