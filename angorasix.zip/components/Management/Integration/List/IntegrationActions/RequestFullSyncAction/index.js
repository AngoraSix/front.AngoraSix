import RequestFullSyncAction from './RequestFullSyncAction.component';

export default RequestFullSyncAction;
