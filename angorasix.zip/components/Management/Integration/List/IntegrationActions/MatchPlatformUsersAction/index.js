import MatchPlatformUsersActionContainer from './MatchPlatformUsersAction.container';

export default MatchPlatformUsersActionContainer;
