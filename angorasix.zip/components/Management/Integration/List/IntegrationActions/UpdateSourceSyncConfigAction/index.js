import UpdateSourceSyncConfigAction from './UpdateSourceSyncConfigAction.component';

export default UpdateSourceSyncConfigAction;
