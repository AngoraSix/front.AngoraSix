import GetSourceSyncAction from './GetSourceSyncAction.component';

export default GetSourceSyncAction;
