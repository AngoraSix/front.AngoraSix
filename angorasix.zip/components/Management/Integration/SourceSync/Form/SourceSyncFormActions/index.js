import SourceSyncFormActions from './SourceSyncFormActions.component';

export default SourceSyncFormActions;
