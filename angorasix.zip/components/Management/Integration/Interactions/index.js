import ManagementIntegrationInteraction from './ManagementIntegrationInteraction.container';

export default ManagementIntegrationInteraction;
