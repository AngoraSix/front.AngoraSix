import React from 'react';
import ManagementTabs from './ManagementTabs.component';

const ManagementTabsContainer = (props) => {
  return <ManagementTabs {...props} />;
};

export default ManagementTabsContainer;
