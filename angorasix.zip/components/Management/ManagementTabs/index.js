import ManagementTabs from './ManagementTabs.container';

export default ManagementTabs;
