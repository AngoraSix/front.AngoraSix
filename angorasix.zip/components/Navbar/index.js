import Navbar from './Navbar.container';

export default Navbar;
