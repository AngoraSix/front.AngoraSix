import Notifications from './Notifications.container';

export default Notifications;
