import NotificationItem from './NotificationItem.component';

export default NotificationItem;
