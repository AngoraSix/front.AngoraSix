import LinkAction from './LinkAction.component';

export default LinkAction;
