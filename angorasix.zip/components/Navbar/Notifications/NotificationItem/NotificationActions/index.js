import NotificationActions from './NotificationActions.component';

export default NotificationActions;
