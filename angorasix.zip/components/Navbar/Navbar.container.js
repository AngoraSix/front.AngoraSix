import React from 'react';
import Navbar from './Navbar.component';

const NavbarContainer = (props) => {
  return <Navbar {...props} />;
};

export default NavbarContainer;
