import ManagementDetailsLayout from './ManagementDetailsLayout';

export default ManagementDetailsLayout;
